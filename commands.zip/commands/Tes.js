module.exports = {
	name: 'ping',
	description: 'Ini Coding Ping',
	execute(message) {
		message.channel.send('Counting Bot Latency...').then((message) => {
		setTimeout(() => {
			message.edit(`:ping_pong: The Ping Of Bot  \`${message.client.ws.ping}\` ms!}\` ms!`);
		}, 1000 * 5);
		});
	},
};